/**
 * Manhope Mobility - Main JavaScript
 */

document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const navbar = document.querySelector('.navbar');
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    const body = document.body;
    const heroSection = document.querySelector('.hero');
    const contactForm = document.getElementById('contactForm');
    const currentYearEl = document.getElementById('currentYear');
    const preloader = document.querySelector('.preloader');
    
    // Constants
    const WHATSAPP_NUMBER = '917736007124';
    const NAVBAR_OFFSET = 80;

    // --- 13. PRELOADER ---
    if (preloader) {
        window.addEventListener('load', () => {
            preloader.style.opacity = '0';
            setTimeout(() => {
                preloader.remove();
            }, 500);
        });
    }

    // --- 12. YEAR IN COPYRIGHT ---
    if (currentYearEl) {
        currentYearEl.textContent = new Date().getFullYear();
    }

    // --- 1 & 14. STICKY NAVIGATION & HIDE/SHOW ON SCROLL ---
    let lastScrollY = window.scrollY;
    let ticking = false;

    const handleScroll = () => {
        const currentScrollY = window.scrollY;
        
        // Sticky Navigation (Solid background)
        if (currentScrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }

        // Hide on scroll down, show on scroll up
        if (currentScrollY > 200) {
            if (currentScrollY > lastScrollY && !navMenu.classList.contains('active')) {
                // Scrolling down
                navbar.classList.add('nav-hidden');
            } else {
                // Scrolling up
                navbar.classList.remove('nav-hidden');
            }
        } else {
            navbar.classList.remove('nav-hidden');
        }

        // --- 9. PARALLAX EFFECT ---
        if (heroSection && window.innerWidth > 768) {
            // Apply subtle parallax to hero content or background
            // Assuming hero has a background we can transform or background-position
            heroSection.style.backgroundPositionY = `${currentScrollY * 0.3}px`;
        }

        lastScrollY = currentScrollY;
        ticking = false;
    };

    window.addEventListener('scroll', () => {
        if (!ticking) {
            window.requestAnimationFrame(() => {
                handleScroll();
            });
            ticking = true;
        }
    });

    // --- 2. MOBILE MENU ---
    const toggleMenu = () => {
        if (!hamburger) return;
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
        body.classList.toggle('no-scroll');
    };

    const closeMenu = () => {
        if (!hamburger) return;
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
        body.classList.remove('no-scroll');
    };

    if (hamburger) {
        hamburger.addEventListener('click', toggleMenu);
    }

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
        if (navMenu && navMenu.classList.contains('active') && !navMenu.contains(e.target) && !hamburger.contains(e.target)) {
            closeMenu();
        }
    });

    // --- 3 & 5. SMOOTH SCROLLING & CLOSE MENU ON LINK CLICK ---
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const targetId = link.getAttribute('href');
            if (targetId.startsWith('#')) {
                e.preventDefault();
                closeMenu();
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    const targetPosition = targetElement.getBoundingClientRect().top + window.scrollY - NAVBAR_OFFSET;
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });

    // --- 4. SCROLL ANIMATIONS (Intersection Observer) ---
    const animationObserverOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const animationObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, animationObserverOptions);

    document.querySelectorAll('.animate-on-scroll').forEach(element => {
        animationObserver.observe(element);
    });

    // --- 5. ACTIVE NAV LINK ON SCROLL ---
    const sectionObserverOptions = {
        root: null,
        rootMargin: `-${NAVBAR_OFFSET + 10}px 0px -60% 0px`,
        threshold: 0
    };

    const sectionObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const id = entry.target.getAttribute('id');
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${id}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }, sectionObserverOptions);

    document.querySelectorAll('section[id]').forEach(section => {
        sectionObserver.observe(section);
    });

    // --- 6. CONTACT FORM ---
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Basic validation
            const name = contactForm.querySelector('[name="fullName"]');
            const phone = contactForm.querySelector('[name="phone"]');
            const service = contactForm.querySelector('[name="service"]');
            
            if (!name?.value || !phone?.value || !service?.value) {
                alert('Please fill in all required fields.');
                return;
            }

            // Simulate form submission
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Sending...';
            submitBtn.disabled = true;

            setTimeout(() => {
                // Create success message
                let successMsg = contactForm.querySelector('.form-success');
                if (!successMsg) {
                    successMsg = document.createElement('div');
                    successMsg.className = 'form-success';
                    successMsg.style.color = 'green';
                    successMsg.style.marginTop = '1rem';
                    successMsg.style.padding = '1rem';
                    successMsg.style.backgroundColor = '#e8f5e9';
                    successMsg.style.borderRadius = '5px';
                    successMsg.style.textAlign = 'center';
                    contactForm.appendChild(successMsg);
                }
                
                successMsg.textContent = 'Thank you! Your message has been sent successfully. We will contact you shortly.';
                
                // Reset form
                contactForm.reset();
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
                
                // Remove success message after 5 seconds
                setTimeout(() => {
                    if (successMsg) successMsg.remove();
                }, 5000);
            }, 1500);
        });
    }

    // --- 7. COUNTER ANIMATION ---
    const animateCounter = (el) => {
        const target = +el.getAttribute('data-count');
        const duration = 2000; // 2 seconds
        let startTime = null;

        const step = (timestamp) => {
            if (!startTime) startTime = timestamp;
            const progress = Math.min((timestamp - startTime) / duration, 1);
            
            // Ease out quad
            const easeProgress = progress * (2 - progress);
            
            el.textContent = Math.floor(easeProgress * target);
            
            if (progress < 1) {
                window.requestAnimationFrame(step);
            } else {
                el.textContent = target; // Ensure exact target is reached
            }
        };
        
        window.requestAnimationFrame(step);
    };

    const counterObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    document.querySelectorAll('.stat-number').forEach(counter => {
        counterObserver.observe(counter);
    });

    // --- 8. TIMELINE SCROLL ---
    // Mostly handled via CSS (overflow-x: auto), but we can add drag-to-scroll if needed
    const timeline = document.querySelector('.timeline');
    if (timeline) {
        let isDown = false;
        let startX;
        let scrollLeft;

        timeline.addEventListener('mousedown', (e) => {
            isDown = true;
            timeline.classList.add('active');
            startX = e.pageX - timeline.offsetLeft;
            scrollLeft = timeline.scrollLeft;
        });
        timeline.addEventListener('mouseleave', () => {
            isDown = false;
            timeline.classList.remove('active');
        });
        timeline.addEventListener('mouseup', () => {
            isDown = false;
            timeline.classList.remove('active');
        });
        timeline.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - timeline.offsetLeft;
            const walk = (x - startX) * 2; // scroll-fast
            timeline.scrollLeft = scrollLeft - walk;
        });
    }

    // --- 10 & 11. CLICK-TO-CALL & WHATSAPP CTA ---
    // Event delegation for better performance
    document.body.addEventListener('click', (e) => {
        // WhatsApp
        const whatsappBtn = e.target.closest('.whatsapp-btn') || e.target.closest('[data-whatsapp]');
        if (whatsappBtn) {
            e.preventDefault();
            window.open(`https://wa.me/${WHATSAPP_NUMBER}`, '_blank');
        }

        // Click-to-call
        const callBtn = e.target.closest('.call-btn');
        if (callBtn) {
            // Only prevent default if it's not already a tel: link
            if (callBtn.tagName !== 'A' || !callBtn.href.startsWith('tel:')) {
                e.preventDefault();
                window.location.href = `tel:+${WHATSAPP_NUMBER}`;
            }
        }
    });

});
